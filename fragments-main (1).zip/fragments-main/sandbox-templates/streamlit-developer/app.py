# Scaffolding for a Streamlit app

import streamlit as st

st.write("Hello, World!")